Alex Zaharia
azaharia@calpoly.edu
LAB 5

Concerns:
- KATZENJAMMER, query 1: couldn't figure out a way of resolving the query without group by
- CSU, query 3: I think my calculation for AVG is wrong
- CSU, query 4: Answer is missing 1999 (when using AND instead of OR)... When I use OR it gives me way to many options
- STUDENTS, query 3: output isn't matching expected result for some reason. I confirmed with professor who said my output was correct.
- CARS, query 3: count is wrong. It seems correct when I checked, but I could be wrong.

In conclusion...
I've learned a lot about how to use SQL so far this quarter. I don't like that we have to use preset databases. I would've liked to use or find my own. I didn't like that we weren't able to use GROUP BY because I wouldn't have had to waste as much time developing queries without it. I can't wait to 'learn; about subselect statements so I can actually use them in lab.


